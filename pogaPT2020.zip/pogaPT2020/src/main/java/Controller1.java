import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class Controller1 {
    @FXML
    Button poga;
    @FXML
    TextField username;
    @FXML
    PasswordField passwordField;
    @FXML
    ImageView myImage;


    public void click() throws Exception {
        PersonList personList = PersonList.getInstance("src/main/java/persons.xml");

        String username = this.username.getText();
        String password = this.passwordField.getText();

        boolean userExists = false;
        for (Person person : personList.getList()) {
            if (person.getUsername().equals(username) && person.getPassword().equals(password)) {
                userExists = true;
                break;
            }
        }

        if (userExists) {
            FXMLLoader loader = new FXMLLoader(getClass().getClassLoader().getResource("test_3.fxml"));
            Parent parent = loader.load();
            Stage stage = (Stage) poga.getScene().getWindow();
            stage.setScene(new Scene(parent));
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Wrong username or password");
            alert.showAndWait();
        }
    }
    public void click1() throws Exception {
        FXMLLoader loader = new FXMLLoader(getClass().getClassLoader().getResource("test_2.fxml"));
        Parent parent = loader.load();
        Stage stage = (Stage) poga.getScene().getWindow();
        stage.setScene(new Scene(parent));
    }
    }


