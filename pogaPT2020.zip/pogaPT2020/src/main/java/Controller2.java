import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.Marshaller;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import javafx.scene.control.Button;
import javafx.scene.control.TextField;
        import javafx.scene.control.ToggleGroup;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class Controller2 {
    @FXML
    Button save, logbk;
    @FXML
    TextField name;
    @FXML
    PasswordField passwordR;
    @FXML
    ToggleGroup group;

    String username;
    String password;

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void save() throws Exception {
        PersonList personList = PersonList.getInstance("src/main/java/persons.xml");

        String username = name.getText();
        String password = passwordR.getText();

        // check if the entered username already exists in the PersonList
        //for (Person p : personList.getList()) {
        for (int i = 0; i < personList.getList().size(); i++) {
            Person p = personList.getList().get(i);

            if (p.getUsername().equals(username)) {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Username already exists");
                alert.showAndWait();
                return;
            }
        }

        // create a new Person object and add it to the PersonList
        Person person = new Person(username, password);
        personList.addPerson(person);


                // create a JAXB context and marshaller
                JAXBContext jaxbContext = JAXBContext.newInstance(PersonList.class);
                Marshaller marshaller = jaxbContext.createMarshaller();
                marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

                // marshal the PersonList object to the selected file
        marshaller.marshal(personList, new FileOutputStream("src/main/java/persons.xml"));
        Alert alert = new Alert(Alert.AlertType.INFORMATION, "User has been registered successfully");
        alert.showAndWait();
    }

    public void logbk() throws Exception {
        FXMLLoader loader = new FXMLLoader(getClass().getClassLoader().getResource("test_1.fxml"));
        Parent parent = loader.load();
        Stage stage = (Stage) logbk.getScene().getWindow();
        stage.setScene(new Scene(parent));
    }
}
