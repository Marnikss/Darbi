import java.text.SimpleDateFormat;
import java.util.Date;

public class exampleWithDate {



    public exampleWithDate(String str)throws Exception{
        Date date =new SimpleDateFormat("dd/MM/yyyy").parse(str);
    }






    public static void main(String[] args) {
        char[] burtuMasivs = {'A', 'B', 'C'};
        int max = burtuMasivs.length-1;
        int min = 0;
        int range = max - min + 1;
        int number = (int) (Math.random()*range + min);
        System.out.println(burtuMasivs[number]);





    }
}
