import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;


public class Controller3 {
    @FXML
    Button rocket, minecraft, rust, roblox;

    public void click10() throws Exception {
        FXMLLoader loader = new FXMLLoader(getClass().getClassLoader().getResource("rockettest.fxml"));
        Parent parent = loader.load();
        Stage stage = (Stage) rocket.getScene().getWindow();
        stage.setScene(new Scene(parent));
    }
    public void click11() throws Exception {
        FXMLLoader loader = new FXMLLoader(getClass().getClassLoader().getResource("rusttest.fxml"));
        Parent parent = loader.load();
        Stage stage = (Stage) rocket.getScene().getWindow();
        stage.setScene(new Scene(parent));
    }
    public void click12() throws Exception {
        FXMLLoader loader = new FXMLLoader(getClass().getClassLoader().getResource("robloxtest.fxml"));
        Parent parent = loader.load();
        Stage stage = (Stage) rocket.getScene().getWindow();
        stage.setScene(new Scene(parent));
    }
    public void click13() throws Exception {
        FXMLLoader loader = new FXMLLoader(getClass().getClassLoader().getResource("minecrafttest.fxml"));
        Parent parent = loader.load();
        Stage stage = (Stage) rocket.getScene().getWindow();
        stage.setScene(new Scene(parent));
    }

}

